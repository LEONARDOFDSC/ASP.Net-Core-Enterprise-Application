﻿namespace NSE.Core.DomainObjects
{
    public interface IAggregateRoot { }
}